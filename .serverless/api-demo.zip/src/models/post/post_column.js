"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class PostColumn {
}
PostColumn.ID = "id";
PostColumn.NAME = "name";
PostColumn.EMAIL = "email";
PostColumn.PHONENO = "phone_no";
PostColumn.USERTYPE = "user_type";
exports.default = PostColumn;
//# sourceMappingURL=post_column.js.map